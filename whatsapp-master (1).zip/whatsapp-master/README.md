# WhatsApp
whatsApp Swag

#Introduction
WhatsApp Messenger is a proprietary, cross-platform, encrypted instant messaging client for smartphones.It uses the Internet to send text messages, documents, images, video, user location and audio messages to other users using standard cellular mobile numbers.
As of February 2016, WhatsApp had a user base of one billion,making it the most popular messaging application.

# Demo 
https://youtu.be/UQYsVd-rI54

# Launch WhatsApp
- Clone
- Npm install in terminal
- Run on IOS simulator or Android emulator
