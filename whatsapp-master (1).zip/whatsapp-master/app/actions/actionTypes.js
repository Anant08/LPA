export const LOGIN = 'LOGIN';
