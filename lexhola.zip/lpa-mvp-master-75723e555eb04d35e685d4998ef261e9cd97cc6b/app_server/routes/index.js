var express = require('express');
var router = express.Router();



var ctrlHome = require('../controllers/main');

router.get('/s/lpa-mvp/chat', ctrlHome.chat);
router.get('/s/lpa-mvp', ctrlHome.screen);
router.get('/s/lpa-mvp/login', ctrlHome.loginlpa);
router.get('/s/lpa-mvp/signup', ctrlHome.joinlpa);
router.all('/s/lpa-mvp/join', ctrlHome.signup);
router.all('/s/lpa-mvp/verify', ctrlHome.verify);
router.get('/s/lpa-mvp/logout', ctrlHome.logout);




module.exports = router;


