var mongoose = require( 'mongoose' );
var gracefulShutdown;
var LPAuser = 'mongodb://localhost/user';

var db_user = mongoose.createConnection(LPAuser);

var RegSchema = mongoose.Schema({
        
        Email: String,
        Pass: String,
        reg_time : {
            type : Date, default: Date.now
        }
    },{ collection : 'user' });
var LogSchema = mongoose.Schema({
        Email: String,
        Token: String,
        reg_time : {
            type : Date, default: Date.now
        }
    },{ collection : 'logins' });






mongoose.connection.on('connected', function () {
console.log('Mongoose connected to ' + dbTaskss);
});
mongoose.connection.on('error',function (err) {
console.log('Mongoose connection error: ' + err);
});
mongoose.connection.on('disconnected', function () {
console.log('Mongoose disconnected');
});
gracefulShutdown = function (msg, callback) {
mongoose.connection.close(function () {
console.log('Mongoose disconnected through ' + msg);
callback();
});
};
// For nodemon restarts
process.once('SIGUSR2', function () {
gracefulShutdown('nodemon restart', function () {
process.kill(process.pid, 'SIGUSR2');
});
});
// For app termination
process.on('SIGINT', function() {
gracefulShutdown('app termination', function () {
process.exit(0);
});
});
// For Heroku app termination
process.on('SIGTERM', function() {
gracefulShutdown('Heroku app shutdown', function () {
process.exit(0);
});
});




