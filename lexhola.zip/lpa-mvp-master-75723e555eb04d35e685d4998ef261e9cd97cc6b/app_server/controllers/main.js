/* GET home page */
var fs = require('fs');
var express = require('express');
var app = express();
var cookieParser = require('cookie-parser');
eval(fs.readFileSync('./app_server/models/db.js')+'');

var UserReg = db_user.model('UserReg', RegSchema);
var UserLog = db_user.model('UserLog', LogSchema);

var crypto = require('crypto'),
    algorithm = 'aes-256-ctr',
    password = 'd6F3Efeq';
    password2 = 'f6F3Efeq';

function randomValueBase64 (len) {
    return crypto.randomBytes(Math.ceil(len * 3 / 4))
        .toString('base64')   // convert to base64 format
        .slice(0, len)        // return required number of characters
        .replace(/\+/g, '0')  // replace '+' with '0'
        .replace(/\//g, '0'); // replace '/' with '0'
}

var token = randomValueBase64(10); 
 

module.exports.chat = function(req, res){
var token2 = randomValueBase64(8);
var tokenm = req.cookies.tokenm;
var tokent = req.cookies.tokent;
res.cookie('token2', token2, { expires: 0, httpOnly: true });
if(tokenm == null && tokent == null){
   res.redirect('http://lpa-mvp.lexhola.com');
   }
else{
   res.render('chat', { title: 'Lexhola' });
    }
};

module.exports.logout = function(req, res){
res.clearCookie('tokenm');
res.clearCookie('tokent');
res.clearCookie('token2');
res.redirect('http://lpa-mvp.lexhola.com');
   
};


module.exports.screen = function(req, res){
var tokenm = req.cookies.tokenm;
var tokent = req.cookies.tokent;
if(tokenm == null && tokent == null){
   res.render('main', { title: 'Lexhola' });
   }
else{
   res.redirect('http://lpa-mvp.lexhola.com/chat');
   }
};

module.exports.joinlpa = function(req, res){
var tokenm = req.cookies.tokenm;
var tokent = req.cookies.tokent;
if(tokenm == null && tokent == null){
   res.render('signup', { title: 'Lexhola' });
   }
else{
   res.redirect('http://lpa-mvp.lexhola.com/chat');
   }
};

module.exports.loginlpa = function(req, res){
var tokenm = req.cookies.tokenm;
var tokent = req.cookies.tokent;

if(tokenm == null && tokent == null){
   res.render('login', { title: 'Lexhola' });
   }
else{
   res.redirect('http://lpa-mvp.lexhola.com/chat');
   }
};

module.exports.verify = function(req, res){
var tokenm = req.cookies.tokenm;
var tokent = req.cookies.tokent;
var user = {
       Email: req.body.username,
       Pass: req.body.password,
   };
var login = {
       Email: req.body.username,
       Token: token,
   };
UserReg.find(user).count(function (err, count){ 
    if(count>0){
                         res.cookie('tokenm', req.body.username, { maxAge: 900000, httpOnly: true });
                         res.cookie('tokent', token, { maxAge: 900000, httpOnly: true });
                         res.redirect('http://lpa-mvp.lexhola.com/chat');
                 
    }
    else{
          res.render('errors2', { title: 'Lexhola' });
        }
     });
          
  



};

module.exports.signup = function(req, res){
var tokenm = req.cookies.tokenm;
var tokent = req.cookies.tokent;
var user = {
       Email: req.body.username,
       Pass: req.body.password,
   };

var user2 = {
       Email: req.body.username,
       Confir: true,
   };

UserReg.count(user2, function (err, count){ 
    if(count>0){
                res.render('errors', { title: 'Lexhola' });
       }
     else{
          UserReg.create(user);
          res.cookie('tokenm', req.body.username, { maxAge: 900000, httpOnly: true });
          res.cookie('tokent', token, { maxAge: 900000, httpOnly: true });
          res.redirect('http://lpa-mvp.lexhola.com/chat');
        }
     });




};
