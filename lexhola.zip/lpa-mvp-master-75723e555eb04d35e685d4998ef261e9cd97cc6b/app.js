var express = require('express');

var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var wildcardSubdomains = require('wildcard-subdomains');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');

var fs = require('fs');
eval(fs.readFileSync('./app_server/models/db.js')+'');


var app = express();
var routes = require('./app_server/routes/index');
var server = require('http').Server(app);
app.use(bodyParser.json()); 
      // to support JSON-encoded bodies
app.use(cookieParser());
app.use(bodyParser.urlencoded({     // to support URL-encoded bodies
  extended: true
}));

app.use(wildcardSubdomains({
  namespace: 's',
  www: 'false',
}));
// view engine setup
app.set('views', path.join(__dirname, 'app_server', 'views'))
app.set('view engine', 'ejs');

// uncomment after placing your favicon in /public
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));

app.get('/s/lpa-mvp', routes);
app.get('/s/lpa-mvp/chat', routes);
app.get('/s/lpa-mvp/login', routes);
app.get('/s/lpa-mvp/signup', routes);
app.get('/s/lpa-mvp/logout', routes);
app.post('/s/lpa-mvp/join', routes);
app.post('/s/lpa-mvp/verify', routes);

const Wit = require('node-wit').Wit;
var fs = require('fs');
var ACCESS_TOKEN = "GCQR7GESFHP7IGPP7I5JIXBGUG7LWESH";

var crypto = require('crypto');

function randomValueBase64 (len) {
    return crypto.randomBytes(Math.ceil(len * 3 / 4))
        .toString('base64')   // convert to base64 format
        .slice(0, len)        // return required number of characters
        .replace(/\+/g, '0')  // replace '+' with '0'
        .replace(/\//g, '0'); // replace '/' with '0'
}
 

app.get('/s/lpa-mvp/searching', function(req, res){
var val = req.query.search;
var token2 = req.cookies.token2; 
  
  
 const client = new Wit({accessToken: ACCESS_TOKEN});
client.converse(token2, val, {})
.then((data) => {
  console.log('Yay, got Wit.ai response: ' + data.msg);
  if(data.msg == null){
     const client = new Wit({accessToken: ACCESS_TOKEN});
client.converse(value1, val, {})
.then((data) => {
  console.log('Yay, got Wit.ai response: ' + data.msg);
  res.send(data.msg);
})
.catch(console.error);
}
 else{                   
  res.send(data.msg);
  }
})
.catch(console.error);

});

app.post('/sign_up/tseam', function (req, res, next) {
    var user = {
       FirstName: req.body.firstname,
       LastName: req.body.lastname,
       Email: req.body.email,
       Pass: req.body.password,
       
   };
   var UserReg = db_user.model('UserReg', RegSchema);;
   UserReg.create(user);
   res.send("done");
});
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/s/:id/', express.static(__dirname + '/public'));


// catch 404 and forward to error handler
app.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// error handlers

// development error handler
// will print stacktrace
if (app.get('env') === 'development') {
  app.use(function(err, req, res, next) {
    res.status(err.status || 500);
    res.render('error', {
      message: err.message,
      error: err
    });
  });
}

// production error handler
// no stacktraces leaked to user
app.use(function(err, req, res, next) {
  res.status(err.status || 500);
  res.render('error', {
    message: err.message,
    error: {}
  });
});




module.exports = app;
routes;
