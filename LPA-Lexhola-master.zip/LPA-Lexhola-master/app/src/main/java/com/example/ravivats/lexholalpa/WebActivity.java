package com.example.ravivats.lexholalpa;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.http.SslError;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Window;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;


public class WebActivity extends AppCompatActivity {
    WebView myWebView;
     static  String content="lpa-mvp.lexhola.com";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web);
        myWebView=(WebView) findViewById(R.id.myWebView);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                myWebView.setInitialScale(1);
                myWebView.getSettings().setJavaScriptEnabled(true);
                myWebView.getSettings().setDomStorageEnabled(true);
                myWebView.getSettings().setBuiltInZoomControls(true);
                myWebView.getSettings().setUseWideViewPort(true);
                myWebView.getSettings().setLoadWithOverviewMode(true);
                myWebView.setWebChromeClient(new WebChromeClient());
                myWebView.setWebViewClient(new WebViewClient() {
                    @Override
                    public boolean shouldOverrideUrlLoading(WebView view, String url) {
                        view.loadUrl(url);
                        return true;
                    }
                    @Override
                    public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                        view.loadUrl("http://"+content+"/");
                        return true;
                    }
                    @Override
                    public void onPageFinished(WebView view, String url) {
                        super.onPageFinished(view, url);
                    }
                    @Override
                    public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                        Log.i("SSL error","here");
                        Intent i=new Intent(WebActivity.this,ErrorActivity.class);
                        startActivity(i);
                    }
                    @Override
                    public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                        Log.i("Recieved error","here");
                        Intent i=new Intent(WebActivity.this,ErrorActivity.class);
                        startActivity(i);
                    }
                    @Override
                    public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                        Log.i("new Recieved error","here");
                        Intent i=new Intent(WebActivity.this,ErrorActivity.class);
                        startActivity(i);
                    }
                });
                //String content="www.google.com";
                myWebView.loadUrl("http://"+content+"/");
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (myWebView.canGoBack()) {
            myWebView.goBack();
        } else {
            Intent intent=new Intent(this,WebActivity.class);
            startActivity(intent);
        }
    }

}
